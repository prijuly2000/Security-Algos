import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class ciphertext 
{
	public static void main(String[] args) 
	{
		String input=args[0];
		String output=args[1];
		
		String line="";
		int charCounts[]=new int[26];		
		
		try 
		{
			FileReader fr=new FileReader(input);
			BufferedReader reader=new BufferedReader(fr);
			StringBuffer strBuf=new StringBuffer();
			while((line=reader.readLine())!=null)
				strBuf.append(line);
			
			String encryptedMsg=new String(strBuf);
			char charArr[]=encryptedMsg.toCharArray();
			
			for (int i = 0; i < charArr.length; i++) 
			{
				if(charArr[i]>96 && charArr[i]<123)
				{
					charCounts[charArr[i]-97]++;
				}				
			}
			
			int maxCount=charCounts[0];
			char maxChar='a';
			for (int i = 0; i < charCounts.length; i++) 
			{				
				if(charCounts[i]>maxCount)
				{
					maxCount=charCounts[i];
					maxChar=(char)(i+97);
				}
			}
			System.out.println("maxChar : "+maxChar+" maxCount : "+maxCount);
			
			int difference=maxChar-'e';
			int shift=difference*(-1);
			char decryptedArr[]=new char[charArr.length];
			
			System.out.println("shift : "+shift);		
			
			for (int i = 0; i < charArr.length; i++) 
			{
				if((charArr[i]+shift)<97)
					decryptedArr[i]=(char)(charArr[i]+shift+26);
				else if((charArr[i]+shift)>122)
					decryptedArr[i]=(char)(charArr[i]+shift-26);
				else
					decryptedArr[i]=(char)(charArr[i]+shift);				
			}
			
			String decryptedMsg=new String(decryptedArr);
			
			FileWriter fw=new FileWriter(output);
			BufferedWriter writer=new BufferedWriter(fw);
			writer.append(decryptedMsg);
			
		} 
		catch (FileNotFoundException e) 
		{			
			e.printStackTrace();
		} 
		catch (IOException e) 
		{			
			e.printStackTrace();
		}
		
				
	}

}
