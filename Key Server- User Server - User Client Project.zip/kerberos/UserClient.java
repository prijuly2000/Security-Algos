package kerberos;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 * This class sends the request to KeyServer for Session key.
 * Session key is stored for the communication here in this class & this class also 
 * sends the encrypted key to the other user server to facilitate the secure communication.
 * @author pritesh gandhi
 *
 */
public class UserClient
{
	public String KS_HOST, OTHER_HOST;
	public int KS_PORT, OTHER_PORT, USER_PORT;
	public byte[] USER_KEY,sessionKey;

	public byte[] longToByteArray(long lock)
	{
		byte[] block = new byte[8];
		for (int i = 7; i >= 0; i--)
		{
			block[i] = (byte) (lock & 0xFFL);
			lock = lock >> 8;
		}
		return block;
	}

	public long byteArrayToLong(byte[] block)
	{
		long lock = 0L;
		for (int i = 0; i < 8; i++)
			lock = (lock << 8) | (block[i] & 0xFFL);
		return lock;
	}

	public static void main(String[] args)
	{
		UserClient userClient = new UserClient();
		DES des=new DES("sboxes_default");
		CBC cbc=new CBC(des);

		userClient.KS_HOST = args[0];
		userClient.KS_PORT = Integer.parseInt(args[1]);
		
		userClient.OTHER_HOST = args[2];
		userClient.OTHER_PORT = Integer.parseInt(args[3]);
		userClient.USER_PORT = Integer.parseInt(args[4]);
		Long userKeyLong = new BigInteger(args[5], 16).longValue();
		userClient.USER_KEY = userClient.longToByteArray(userKeyLong);
		System.out.println("UserClient running port :"+userClient.KS_PORT);


		
		
		
		try(
				Socket server = new Socket(userClient.KS_HOST, userClient.KS_PORT);
				BufferedReader stdIn=new BufferedReader(new InputStreamReader(System.in));
				Socket userServer = new Socket(userClient.OTHER_HOST,userClient.OTHER_PORT);
				BufferedOutputStream os=new BufferedOutputStream( server.getOutputStream());		
				BufferedInputStream is= new BufferedInputStream(server.getInputStream());
				BufferedOutputStream bos=new BufferedOutputStream( userServer.getOutputStream());			
				InputStream bis=userServer.getInputStream();
				
				)
		{
			
			
			System.out.println("Connection established....");
			byte []portBytes=new byte [4];
			portBytes[0]=(byte) (userClient.USER_PORT & 0xFF);
			portBytes[1]=(byte) ((userClient.USER_PORT >> 8) & 0xFF);
			portBytes[2]=(byte)(userClient.OTHER_PORT & 0xFF);
			portBytes[3]=(byte) ((userClient.OTHER_PORT >> 8) & 0xFF);
			
			
				
			os.write(portBytes);
			os.flush();
			
			byte []data=new byte[16];
			StringBuffer sBuff=new StringBuffer();
			is.read(data);
			
			byte []encSesKeyA=new byte[8];
			byte []encSesKeyB=new byte[8];
			for (int i = 0; i < 8; i++)
			{
				encSesKeyA[i]=data[i];
			}
			for (int i = 8; i < data.length; i++)
			{
				encSesKeyB[i-8]=data[i];
			}
			
			
			String input=new String(data);
			
			byte []encSesWithBKey=des.decrypt(userClient.USER_KEY,encSesKeyB );
			userClient.sessionKey=des.decrypt(userClient.USER_KEY, encSesKeyA);
			System.out.println("session key at A: "+Long.toHexString(userClient.byteArrayToLong(userClient.sessionKey)));
			
			byte[] firstMsg=("I'm waiting for your response : ").getBytes();
			int preIV= firstMsg.length + 8 - (firstMsg.length %8);
			System.out.println("Pre IV : "+preIV);
			byte []iv=new byte[8];
			iv[0]=(byte) (preIV & 0xFF);
			iv[1]=(byte) ((preIV >> 8) & 0xFF);
			for (int i = 2; i < iv.length; i++)
			{
				iv[i]=0x00;
			}
			System.out.println("here");
			cbc.setIV(iv);
			byte [] encFirstMsg=cbc.encrypt(userClient.sessionKey, firstMsg);
			System.err.println("Default msg sent : "+new String(firstMsg));
			
			
			bos.write(encSesWithBKey);
			bos.write(encFirstMsg);			
			bos.flush();
			
			
			byte []encMsg;
			String consoleInput;
			
			while(true)
			{
				System.out.println("(User Server turn)");
				encMsg=new byte[500];
				bis.read(encMsg);
				byte []plaintext=cbc.decrypt(userClient.sessionKey, encMsg);
				System.out.println("UserServer says : "+new String(plaintext));
				System.err.println();
				System.err.println("Your Turn : ");
				consoleInput=stdIn.readLine();
				preIV= consoleInput.length() + 8 - (consoleInput.length() %8);
				
				iv=new byte[8];
				iv[0]=(byte) (preIV & 0xFF);
				iv[1]=(byte) ((preIV >> 8) & 0xFF);
				for (int i = 2; i < iv.length; i++)
				{
					iv[i]=0x00;
				}
				cbc.setIV(iv);
				bos.write(cbc.encrypt(userClient.sessionKey, consoleInput.getBytes()));
				bos.flush();				
				
			}
			
		} 
		catch (UnknownHostException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
