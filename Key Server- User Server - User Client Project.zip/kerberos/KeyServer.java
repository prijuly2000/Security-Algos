package kerberos;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Random;



/**
 * This class provides a session key for every communication channel.
 * The user client sends a request for session key then Key 
 * server generates the key & sends it back to the client
 * @author pritesh gandhi
 *
 */
public class KeyServer
{
	public byte[] sessionKey;
	public int serverPort;
	public HashMap<Integer, byte[]> portKeyMap;
	

	public KeyServer()
	{
		this.sessionKey=new byte[8];
		
		portKeyMap = new HashMap<>();
		
	}

	public byte[] longToByteArray(long lock)
	{
		byte[] block = new byte[8];
		for (int i = 7; i >= 0; i--)
		{
			block[i] = (byte) (lock & 0xFFL);
			lock = lock >> 8;
		}
		return block;
	}

	public long byteArrayToLong(byte[] block)
	{
		long lock = 0L;
		for (int i = 0; i < 8; i++)
			lock = (lock << 8) | (block[i] & 0xFFL);
		return lock;
	}

	/**
	 * This method generates a random session key.
	 * @return key
	 */
	public byte[] randomSessionKey()
	{	
		byte []key=new byte[8];
		Random rand=new Random();
		for(int i=0;i<8;i++)
		{
			key[i]=(byte)rand.nextInt(255);
		}
		return key;
		
	}
	public static void main(String[] args)
	{
		int serverPort = Integer.parseInt(args[0]);
		DES des=new DES("sboxes_default");
		CBC cbc=new CBC(des);
		
		KeyServer keyServer = new KeyServer();

		keyServer.serverPort = serverPort;
		for (int i = 1; i < args.length; i++)
		{
			int userPort = Integer.parseInt(args[i++]);
			long userKeyLong = new BigInteger(args[i], 16).longValue();
			byte[] userKey = keyServer.longToByteArray(userKeyLong);

			keyServer.portKeyMap.put(userPort, userKey);

		}
		System.out.println("Server running on port : "+keyServer.serverPort);
		
				
		try(
				ServerSocket server=new ServerSocket(keyServer.serverPort);
				Socket client = server.accept();
				BufferedInputStream is =new BufferedInputStream(client.getInputStream());
				OutputStream os =client.getOutputStream();	
				
				)
		{			
			
			
			while (true)
			{
				System.out.println("Waiting for conection...");
				
				System.out.println("Connection established with user client. ");
				
				byte[] data = new byte[4];
				is.read(data);
				
				String input = new String(data);
				//System.out.println("Client Message : " + input);
				int portA=((data[1]&0xff)<<8) | (data[0] & 0xff); //Integer.parseInt( input.substring(0, 4),16);
				int portB=((data[3]&0xff)<<8) | (data[2] & 0xff);  //Integer.parseInt( input.substring(4, 8),16);				
				System.out.println("Ports Received:"+portA+" "+portB);
				
				byte keyB[]=keyServer.portKeyMap.get(portB);
				byte []sessionKey=keyServer.randomSessionKey();
				
				//System.out.println("Session Key byte Length :"+Long.toHexString(sessionKeyLong).getBytes().length);
				
				byte []encSessionKeyA = des.encrypt(keyServer.portKeyMap.get(portA),sessionKey );
				long encSessionKeyALong=keyServer.byteArrayToLong(encSessionKeyA);
				byte []encWithAForB=des.encrypt(keyServer.portKeyMap.get(portB), sessionKey);
				byte []encSessionKeyB=des.encrypt(keyServer.portKeyMap.get(portA),encWithAForB );
				long encSessionKeyBlong=keyServer.byteArrayToLong(encSessionKeyB);
				System.out.println("Session key : "+Long.toHexString(keyServer.byteArrayToLong(sessionKey)));
				
				os.write(encSessionKeyA);
				os.write(encSessionKeyB);
				os.flush();
				
			
			}
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		

	}

}
