package kerberos;

import java.awt.List;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * UserServer is the class that takes session key from the userclient & stores
 * in the session key. This class requires key (in hex string) & user port
 * (decimal) as run configuration.
 * 
 * 
 * @author pritesh gandhi
 *
 */
public class UserServer
{

	int USER_PORT;
	byte[] USER_KEY, sessionKey;

	public UserServer()
	{
	}


	
	/**
	 * This method converts the long data to byte array.
	 * @param lock
	 * @return
	 */
	public byte[] longToByteArray(long lock)
	{
		byte[] block = new byte[8];
		for (int i = 7; i >= 0; i--)
		{
			block[i] = (byte) (lock & 0xFFL);
			lock = lock >> 8;
		}
		return block;
	}

	
	/**
	 * This method is used to convert the byte array to long value.
	 * @param block
	 * @return
	 */
	public long byteArrayToLong(byte[] block)
	{
		long lock = 0L;
		for (int i = 0; i < 8; i++)
			lock = (lock << 8) | (block[i] & 0xFFL);
		return lock;
	}

	public static void main(String[] args)
	{
		UserServer userServer = new UserServer();
		userServer.USER_PORT = Integer.parseInt(args[0]);
		long userKeyLong = new BigInteger(args[1], 16).longValue();
		userServer.USER_KEY = userServer.longToByteArray(userKeyLong);
		DES des = new DES("sboxes_default");
		CBC cbc = new CBC(des);

		
		try(
				ServerSocket server = new ServerSocket(userServer.USER_PORT);
				Socket client = server.accept();
				InputStream is = client.getInputStream();
				BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
				OutputStream os = client.getOutputStream();
				)
		{
			

			System.out.println("User Server Waiting for conection...");
			
			System.out.println("Connection established with user client. ");

			
			byte[] data = new byte[100];

			byte[] encSesKeyB = new byte[8];
			is.read(data);
			for (int i = 0; i < 8; i++)
			{
				encSesKeyB[i] = data[i];
			}
			byte[] encData = new byte[100];
			for (int i = 8; i < data.length; i++)
			{
				encData[i - 8] = data[i];
			}

			userServer.sessionKey = des.decrypt(userServer.USER_KEY, encSesKeyB);
			System.err.println("Session key at B: "	+ Long.toHexString(userServer.byteArrayToLong(userServer.sessionKey)));

			byte[] msg = cbc.decrypt(userServer.sessionKey, encData);
			System.err.println("Default Client msg: " + new String(msg));
			
			String consoleInput;
			byte[] encMsg;
			byte[] incomingMsg;
			System.err.println("\nYour Turn : ");
			while ((consoleInput = stdIn.readLine()) != null)
			{
				int preIV= consoleInput.length() + 8 - (consoleInput.length() %8);				
				byte []iv=new byte[8];
				iv[0]=(byte) (preIV & 0xFF);
				iv[1]=(byte) ((preIV >> 8) & 0xFF);
				for (int i = 2; i < iv.length; i++)
				{
					iv[i]=0x00;
				}
				cbc.setIV(iv);
				encMsg = cbc.encrypt(userServer.sessionKey,consoleInput.getBytes());
				os.write(encMsg);

				System.out.println("(User Client turn)");
				incomingMsg = new byte[500];
				is.read(incomingMsg);
				byte plaintext[] = cbc.decrypt(userServer.sessionKey,incomingMsg);
				System.out.println("User Client says : "+ new String(plaintext));
				System.err.println("\nYour Turn : ");
				System.out.println();

			}
		} catch (IOException ex)
		{
			ex.printStackTrace();

		}

	}
}
