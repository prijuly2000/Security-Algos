package kerberos;

import java.util.Random;


/**
 * CBC implements all the methods of BlockCipherMode interface. This class
 * provides an option to set or randomly generate the IV for the whole
 * encryption process. DES class is used to implement the encryption and
 * decryption process. CBC class does all the operations on arbitrary length
 * inputs. The input is first converted to fixed size which is multiple of 64 so
 * that DES can be applied on it per block.
 * 
 * @author Pritesh Gandhi
 *
 */
public class CBC implements BlockCipherMode
{

	byte []iv=new byte[8];
	BlockCipher des;
	
	public CBC(BlockCipher des)
	{
		this.des=des;
	}
	
	@Override
	public void setIV(byte[] iv)
	{
		this.iv=iv;	
		//System.err.println("set IV : ");
		//byteArrayToLong(this.iv);
	}

	/**
	 * randomIV generates random IV for the encryption.
	 */
	@Override
	public void randomIV()
	{		
		Random rand=new Random();
		for(int i=0;i<8;i++)
		{
			iv[i]=(byte)rand.nextInt(255);
		}
		
	}

	@Override
	public byte[] getIV()
	{		
		return iv;
	}

	@Override
	public byte[] encrypt(byte[] key, byte[] plaintext)
	{
		//System.out.println("---------Encrypt--------");
		byte []ciphertext=null;
		byte []paddedPlaintext=null;
		int outputLength;
		int padBytesNo,padIterator;
		
		// Check input is multiple of 8 bytes
		// If yes then add one block else add the required bytes.
		if(plaintext.length%8==0)
		{
			padBytesNo=8;
			outputLength= plaintext.length+8+padBytesNo;
		}
		else
		{
			padBytesNo=8-plaintext.length%8;
			outputLength=plaintext.length+8+padBytesNo;			
		}
		//System.out.println("Pad bytes number:"+padBytesNo);
		//System.out.println("After Pad length : "+(plaintext.length+padBytesNo));
		paddedPlaintext=new byte[plaintext.length+padBytesNo];
		ciphertext=new byte[outputLength];
		
		// Copy the input as it is.
		for (padIterator = 0; padIterator < plaintext.length; padIterator++)
		{
			paddedPlaintext[padIterator]=plaintext[padIterator];
		}
		
		// Add one byte of 128 value.
		paddedPlaintext[padIterator++]=(byte)0x80;
		
		// Add 0 value bytes for remaining bytes. 
		while(padIterator<paddedPlaintext.length)
		{
			paddedPlaintext[padIterator++]=(byte)0x00;
		}
		
		// Copy IV to cipher as it is.
		for (int i = 0; i < iv.length; i++)
		{
			ciphertext[i]=iv[i];
		}			
		
		byte []currentPlainBlock=new byte[8];
		byte []currentCipherBlock=iv;
		int totalBlocks=paddedPlaintext.length/8;
		int k;
		//System.out.println("Total blocks: "+totalBlocks);
		for (int i = 0; i < totalBlocks; i++)
		{
			//System.out.println("Encryption iteration:"+i);
			for (int j = i*8,m=0; j < i*8+8; j++)
			{
				currentPlainBlock[m]=(byte)(paddedPlaintext[j] ^ currentCipherBlock[m]);
				m++;
			}
			currentCipherBlock=des.encrypt(key, currentPlainBlock);
			k=i+1;
			
			for (int j = k*8,m=0; j < k*8+8; j++)
			{
				ciphertext[j]=currentCipherBlock[m++];
			}
			
		}
		
		return ciphertext;
	}

	/**
	 * decrypt function accepts byte array key & byte array ciphertext for decryption.
	 * The ciphertext is always multiple of 64 bit block in length.
	 * This method uses DES decrypt method to perform decryption.
	 */
	@Override
	public byte[] decrypt(byte[] key, byte[] ciphertext)
	{
		//System.out.println("---------Decrypt---------");
		
		// Set IV from first block of incoming encrypted data 
		for (int i = 0; i < iv.length; i++)
		{
			
			iv[i]= ciphertext[i];
		}
		
		byte paddedPlaintext[]=new byte[ciphertext.length-8];
		byte []currentPlainBlock=new byte[8];
		byte []prevCipherBLock=iv;
		byte []currentCipherBlock=new byte[8];
		int totalBlocks=paddedPlaintext.length/8;
		byte []tempXOR=new byte[8];
		
		int k=8,m=0;
		for (int i = 0; i < totalBlocks; i++)
		{
			//System.out.println("\nDecryption iteration"+i);
			// Take the next 64 bit block to operate DES encryption on it.  
			for (int j = 0; j < currentCipherBlock.length; j++)
			{
				currentCipherBlock[j]=ciphertext[k++];
			}
			currentPlainBlock=des.decrypt(key, currentCipherBlock);
			for(int j=0;j<currentCipherBlock.length;j++)
			{
				tempXOR[j]=(byte)(currentPlainBlock[j]^prevCipherBLock[j]);
				paddedPlaintext[m++]=(byte)(tempXOR[j]);
			}
			prevCipherBLock=currentCipherBlock;
			currentCipherBlock=new byte[8];
			//byteArrayToLong(tempXOR);
			
		}
		//byteArrayToLong(paddedPlaintext);
		int i;
		for (i = paddedPlaintext.length-1; (paddedPlaintext[i] & 0xff)!=128 ; i--);
		
		//System.out.println("\nUnpadded length:"+i);
		byte []plaintext=new byte[i];
		for (int j = 0; j < i; j++)
		{
			plaintext[j]=paddedPlaintext[j];
		}
		//System.out.println("This is the plaintext");
		//byteArrayToLong(plaintext);
		return plaintext;
	}
	
	/**
	 * byteArrayToLong method is used to display the data through out the
	 * program to keep track of encryption & decryption	 * 
	 * @param block contains data to be displayed
	 * @return the long value result of byte array
	 */
	public long byteArrayToLong(byte[] block) 
	{
        long lock = 0L;
        //System.out.println("Length:"+(block.length));
        for (int i = 0; i < block.length; i++)
		{        	
			//System.err.print(" "+(block[i] & 0xff));
		}
        //System.out.println();       
        return lock;
    }
		
	public static void main(String[] args)
	{
		DES des=new DES("sboxes_default");
		CBC cbc=new CBC(des);
		cbc.randomIV();
		byte []iv=new byte[]{0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
		byte []plaintext=new byte[]{(byte)0x01,(byte)0x23,(byte)0x45,(byte)0x67,(byte)0x89,(byte)0xab,(byte)0xcd,(byte)0xef};
		byte []key=new byte[]{(byte)0x6a,(byte)0x92,(byte)0x6b,(byte)0xfe,(byte)0x2a,(byte)0x29,(byte)0xfa,(byte)0xc3};
		//cbc.setIV(iv);
		//System.out.println("-----------CBC-----------");
		
		//Encrytion called
		byte []ciphered = cbc.encrypt(key,plaintext);
		
		// Decryption called
		cbc.decrypt(key, ciphered);
	}
}
