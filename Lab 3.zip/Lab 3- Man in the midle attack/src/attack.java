import java.util.Hashtable;
import java.util.Random;


public class attack 
{
	public static void main(String[] args)
	{
		Random generator=new Random();
		int range=(int)Math.pow(2, 16);
		int number=10;
		Hashtable<Integer, Integer> keyTable=new Hashtable<>();
		
		for (int i = 0; i <range; i++)
		{
			number=generator.nextInt();
			keyTable.put(number,number);
						
		}
		
		Random check=new Random();
		int miss=0;
		range=(int)Math.pow(2, 32);
		for (int i = 0; i < range; i++)
		{
			number=check.nextInt();
			if(keyTable.containsKey(number))
			{
				System.out.println("Collission after "+miss);
				miss=0;
			}
			miss++;
		}
	}
s
}
