package echo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import cipher.CBC;
import cipher.DES;

public class EchoClient
{
	public static void main(String[] args)
	{
		byte []key=new byte[]{(byte)0x6a,(byte)0x92,(byte)0x6b,(byte)0xfe,(byte)0x2a,(byte)0x29,(byte)0xfa,(byte)0xc3};
		DES des=new DES("sboxes_default");
		CBC cbc=new CBC(des);
		byte []iv=new byte[]{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
		cbc.setIV(iv);
		
		String hostName=args[0];
		int portNumber=Integer.parseInt(args[1]);
		
		System.out.println("Host : "+hostName+" Port : "+ portNumber);
		
		try(
			Socket echoSocket=new Socket(hostName,portNumber);
			PrintWriter out=new PrintWriter(echoSocket.getOutputStream(), true);
			BufferedReader in=new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
			BufferedReader stdIn=new BufferedReader(new InputStreamReader(System.in));
			)
			{
				String userInput;
				while((userInput=stdIn.readLine())!=null)
				{
					byte []plaintext= userInput.getBytes();
					byte []ciphered= cbc.encrypt(key, plaintext);
					String mac=null;
					int k=0;
					
					for (int i = ciphered.length-9; i < ciphered.length; i++)
					{
						mac+=Byte.toString(ciphered[i]);
					}
					//System.out.println("MAC : "+mac);
					out.println(mac+"$"+userInput);
					
				}
			
		
			} 
		catch (UnknownHostException e)
			{
				System.out.println("Host not found");
				e.printStackTrace();
			}
		catch (IOException e)
			{
				System.out.println("IO failed");
				e.printStackTrace();
			}
	}
}
