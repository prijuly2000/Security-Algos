package echo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import cipher.CBC;
import cipher.DES;

public class EchoServer
{
	public static void main(String[] args)
	{
		byte []key=new byte[]{(byte)0x6a,(byte)0x92,(byte)0x6b,(byte)0xfe,(byte)0x2a,(byte)0x29,(byte)0xfa,(byte)0xc3};
		DES des=new DES("sboxes_default");
		CBC cbc=new CBC(des);
		byte []iv=new byte[]{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
		cbc.setIV(iv);
		
		int portNumber=Integer.parseInt(args[0]);
		System.out.println("Server running on port "+portNumber);
		try(
			ServerSocket server=new ServerSocket(portNumber);
			Socket client=server.accept();
			PrintWriter out=new PrintWriter(client.getOutputStream(),true);
			BufferedReader in =new BufferedReader(new InputStreamReader(client.getInputStream()));
			)
			{
				String inputLine;
				while((inputLine=in.readLine())!=null)
				{					
					//out.println(inputLine);
					//System.out.println("Read : "+inputLine);
					
					
					String computedMac=null;
					int k=0;
					
					String receivedMac=inputLine.substring(0,inputLine.indexOf("$"));
					//System.out.println("MAC :"+receivedMac);
					String msg=inputLine.substring(inputLine.indexOf("$")+1);
					//System.out.println("MSG :"+msg);
					byte []plaintext= msg.getBytes();
					byte []ciphered= cbc.encrypt(key, plaintext);
					for (int i = ciphered.length-9; i < ciphered.length; i++)
					{
						computedMac+=Byte.toString(ciphered[i]);
					}
					// MAC Changed
					//computedMac="Attacked!!";
					
					if(receivedMac.equals(computedMac))
					{						
						System.out.println("Message :"+msg);
					}
					else
					{
						System.err.println("YOU ARE BEING ATTACKED!!");
					}
					
				}
		
			} 
		catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
